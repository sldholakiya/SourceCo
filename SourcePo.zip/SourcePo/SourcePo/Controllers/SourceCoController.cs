﻿using SourcePo.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SourcePo.Controllers
{
    public class SourceCoController : ApiController
    {
        public IHttpActionResult GetWords(double amount)
        {
            var amountInWords = AmountToWords.Convert(amount);
            return Ok(amountInWords);
        }
    }
}
