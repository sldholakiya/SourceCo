﻿
(function () {
    "use strict";

    var app = angular.module("sourceco", ["ngRoute", "ngResource"]);

    app.config(["$routeProvider", function ($routeProvider) {
        $routeProvider
            .when('/',
            {
                controller: 'getInfoController',
                templateUrl: '/Home/GetInfo'
            })
            .when('/detail',
            {
                controller: 'detailController',
                templateUrl: '/Home/Detail'
            })
            .otherwise({ redirectTo: '/' });
    }]);
}());