﻿(function () {
    "use strict";

    var app = angular.module("sourceco");
    app.controller("detailController", ["$scope", "$http", "$location", "$log", "appSerice", detailController]);

    function detailController($scope, $http, $location, $log, appSerice) {
        $scope.detail = appSerice.getInfo();
    };
}());