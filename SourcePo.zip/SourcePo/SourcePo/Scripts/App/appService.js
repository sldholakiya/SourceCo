﻿

(function () {
    "use strict";

    var app = angular.module("sourceco");
    app.service('appSerice', function () {
        this.detail = {};

        this.setInfo = function (fullName, amount, amountInWords) {
            this.detail = { fullName: fullName, amount: amount, amountInWords: amountInWords };
        }

        this.getInfo = function () {
            return this.detail;
        }
        
    });
}());