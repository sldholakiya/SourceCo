﻿(function () {
    "use strict";

    var app = angular.module("sourceco");
    app.controller("getInfoController", ["$scope", "$http", "$location", "$log", "appSerice", getInfoController]);

    function getInfoController($scope, $http, $location, $log, appSerice) {
        
        $scope.test = "testing....";

        $scope.submit = function (infoForm) {
            $http({
                method: 'GET',
                url: '/api/sourceco/GetWords?amount=' + $scope.amount
            }).then(function successCallback(response) {
                $scope.amountInWords = response.data;
                appSerice.setInfo($scope.fullName, $scope.amount, $scope.amountInWords);
                $location.path('/detail');
            }, function errorCallback(response) {
            });
        };
    };
}());