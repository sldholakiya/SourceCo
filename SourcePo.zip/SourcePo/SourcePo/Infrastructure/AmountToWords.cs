﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SourcePo.Infrastructure
{
    public class AmountToWords
    {
        private static string[] tensNames = { "", " ten", " twenty", " thirty", " forty", " fifty", " sixty", " seventy", " eighty", " ninety" };
        private static string[] numNames = { "", " one", " two", " three", " four", " five", " six", " seven", " eight", " nine", " ten", " eleven", " twelve", " thirteen", " fourteen", " fifteen", " sixteen", " seventeen", " eighteen", " nineteen" };

        private static string ConvertLessThanOneThousand(int number)
        {
            String soFar;

            if (number % 100 < 20)
            {
                soFar = numNames[number % 100];
                number /= 100;
            }
            else
            {
                soFar = numNames[number % 10];
                number /= 10;

                soFar = tensNames[number % 10] + soFar;
                number /= 10;
            }
            if (number == 0) return soFar;
            return numNames[number] + " hundred" + soFar;
        }


        private static string ConvertCents(string result, int number)
        {
            if (number == 0)
                return string.Empty;

            var soFar = string.Empty;

            if (number % 100 < 20)
            {
                soFar = numNames[number % 100];
                number /= 100;
            }
            else
            {
                soFar = numNames[number % 10];
                number /= 10;

                soFar = tensNames[number % 10] + soFar;
                number /= 10;
            }
            return (result.Length > 0 ? result + " and " : string.Empty) + soFar + " cent";
        }


        public static string Convert(double number)
        {
            if (number == 0) { return "zero"; }

            String snumber = number.ToString("000000000000.00");

            
            int billions = System.Convert.ToInt32(snumber.Substring(0, 3));
            
            int millions = System.Convert.ToInt32(snumber.Substring(3, 3));
            
            int hundredThousands = System.Convert.ToInt32(snumber.Substring(6, 3));
            
            int thousands = System.Convert.ToInt32(snumber.Substring(9, 3));

            int cents = System.Convert.ToInt32(snumber.Substring(13, 2));

            String tradBillions;
            switch (billions)
            {
                case 0:
                    tradBillions = "";
                    break;
                case 1:
                    tradBillions = ConvertLessThanOneThousand(billions)
                    + " billion ";
                    break;
                default:
                    tradBillions = ConvertLessThanOneThousand(billions) + " billion ";
                    break;
            }
            String result = tradBillions;

            String tradMillions;
            switch (millions)
            {
                case 0:
                    tradMillions = "";
                    break;
                case 1:
                    tradMillions = ConvertLessThanOneThousand(millions)
                       + " million ";
                    break;
                default:
                    tradMillions = ConvertLessThanOneThousand(millions) + " million ";
                    break;
            }
            result = result + tradMillions;

            String tradHundredThousands;
            switch (hundredThousands)
            {
                case 0:
                    tradHundredThousands = "";
                    break;
                case 1:
                    tradHundredThousands = "one thousand ";
                    break;
                default:
                    tradHundredThousands = ConvertLessThanOneThousand(hundredThousands) + " thousand ";
                    break;
            }
            result = result + tradHundredThousands;


            String tradThousand;
            tradThousand = ConvertLessThanOneThousand(thousands);
            result = result + tradThousand;
            if (result != string.Empty)
                result = result + " dollars ";
            if (cents > 0)
                result = ConvertCents(result, cents);
            return result.TrimEnd().TrimStart().Replace("  ", " ");
        }

    }
    
}