﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using SourcePo.Infrastructure;

namespace SourceCoTests
{
    [TestFixture]
    public class UnitTest1
    {
        [TestCase(10, ExpectedResult = "ten dollars")]
        [TestCase(110, ExpectedResult = "one hundred ten dollars")]
        [TestCase(1000, ExpectedResult = "one thousand dollars")]
        [TestCase(10000, ExpectedResult = "ten thousand dollars")]
        [TestCase(100000, ExpectedResult = "one hundred thousand dollars")]
        [TestCase(1000000, ExpectedResult = "one million dollars")]
        [TestCase(10000000, ExpectedResult = "ten million dollars")]
        [TestCase(100000000, ExpectedResult = "one hundred million dollars")]
        [TestCase(1000000000, ExpectedResult = "one billion dollars")]
        [TestCase(10000000000, ExpectedResult = "ten billion dollars")]
        [TestCase(100000000000, ExpectedResult = "one hundred billion dollars")]
        public string NumbericTest(double number)
        {
            // act
            var result = AmountToWords.Convert(number);

            // assert
            return result;
        }


        [TestCase(.5, ExpectedResult = "fifty cent")]
        [TestCase(.45, ExpectedResult = "forty five cent")]
        [TestCase(.99, ExpectedResult = "ninety nine cent")]
        public string CentTest(double number)
        {
            // act
            var result = AmountToWords.Convert(number);

            // assert
            return result;
        }



        [TestCase(10.5, ExpectedResult = "ten dollars and fifty cent")]
        [TestCase(100.40, ExpectedResult = "one hundred dollars and forty cent")]
        [TestCase(1000.85, ExpectedResult = "one thousand dollars and eighty five cent")]
        [TestCase(10500.30, ExpectedResult = "ten thousand five hundred dollars and thirty cent")]
        public string FullTest(double number)
        {
            // act
            var result = AmountToWords.Convert(number);

            // assert
            return result;
        }


    }

}
